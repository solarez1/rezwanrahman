# I expect you to replace this file with your local config
REGION = event['ResourceProperties']['Region']' # Change to region your AWS Lambda function is in
CHEF_SERVER_URL = 'https://my_server/organizations/thisorg'
USERNAME = event['ResourceProperties']['Username']
VERIFY_SSL = False
DEBUG = False
